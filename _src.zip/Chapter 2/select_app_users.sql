select id
,      username
,      password
,      role
from   app_users;
