insert into EMP_JOB_TITLES (job_no, job_title, language)
values (1, 'PRESIDENT', 'en');
insert into EMP_JOB_TITLES (job_no, job_title, language)
values (2, 'MANAGER', 'en');
insert into EMP_JOB_TITLES (job_no, job_title, language)
values (3, 'ANALYST', 'en');
insert into EMP_JOB_TITLES (job_no, job_title, language)
values (4, 'CLERK', 'en');
insert into EMP_JOB_TITLES (job_no, job_title, language)
values (5, 'SALESMAN', 'en');
insert into EMP_JOB_TITLES (job_no, job_title, language)
values (1, 'Directeur', 'nl');
insert into EMP_JOB_TITLES (job_no, job_title, language)
values (2, 'Manager', 'nl');
insert into EMP_JOB_TITLES (job_no, job_title, language)
values (3, 'Analist', 'nl');
insert into EMP_JOB_TITLES (job_no, job_title, language)
values (4, 'Klerk', 'nl');
insert into EMP_JOB_TITLES (job_no, job_title, language)
values (5, 'Verkoper', 'nl');
