create table EMP_JOB_TITLES
(
  job_no    NUMBER,
  job_title VARCHAR2(32),
  language  VARCHAR2(10)
);